from typing import List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlmodel.ext.asyncio.session import AsyncSession

from app.db.session import get_session
from app.dependencies.auth import get_current_user
from app.models.user import User
from app.schema.propfirm_registration import PropFirmRegistrationCreate, PropFirmRegistrationRead
from app.service.propfirm_registration_service import PropFirmRegistrationService

router = APIRouter()

@router.post("", response_model=PropFirmRegistrationRead)
async def create_propfirm_registration(
    registration: PropFirmRegistrationCreate,
    current_user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
):
    service = PropFirmRegistrationService(session)
    return await service.create_registration(registration, current_user.id)

@router.get("", response_model=List[PropFirmRegistrationRead])
async def read_propfirm_registrations(
    status: str | None = None,
    current_user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
):
    service = PropFirmRegistrationService(session)
    return await service.get_registrations_by_user(current_user.id, status)

@router.get("/{registration_id}", response_model=PropFirmRegistrationRead)
async def read_propfirm_registration(
    registration_id: UUID,
    current_user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
):
    service = PropFirmRegistrationService(session)
    registration = await service.get_registration(registration_id)
    if not registration or registration.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Registration not found")
    return registration
