from uuid import UUID
from typing import List
from sqlmodel import select
from app.models.propfirm_registration import PropFirmRegistration
from app.schema.propfirm_registration import PropFirmRegistrationCreate, PropFirmRegistrationUpdate
from app.repository.base_repo import BaseRepository

class PropFirmRegistrationRepository(BaseRepository[PropFirmRegistration, PropFirmRegistrationCreate, PropFirmRegistrationUpdate]):
    async def get_by_user(self, user_id: UUID, status: str | None = None) -> List[PropFirmRegistration]:
        query = select(self.model).where(self.model.user_id == user_id)
        if status:
            query = query.where(self.model.account_status == status)
        result = await self.session.exec(query)
        return result.all()
