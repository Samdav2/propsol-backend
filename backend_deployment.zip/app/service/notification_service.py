from typing import List
from uuid import UUID
from fastapi import BackgroundTasks
from sqlmodel.ext.asyncio.session import AsyncSession

from app.models.notification import Notification, NotificationType
from app.repository.notification_repo import NotificationRepository
from app.schema.notification import NotificationCreate

class NotificationService:
    def __init__(self, session: AsyncSession):
        self.repo = NotificationRepository(Notification, session)

    async def create_notification(self, notification_in: NotificationCreate) -> Notification:
        return await self.repo.create(notification_in)

    async def get_user_notifications(self, user_id: UUID) -> List[Notification]:
        return await self.repo.get_by_user(user_id)

    async def get_admin_notifications(self, admin_id: UUID) -> List[Notification]:
        return await self.repo.get_by_admin(admin_id)

    async def create_status_change_notification(self, user_id: UUID, status: str, propfirm_name: str) -> Notification:
        title = f"PropFirm Account {status.title()}"
        message = f"Your account for {propfirm_name} has been marked as {status}."
        type_map = {
            "passed": NotificationType.PASSED_ACCOUNT,
            "failed": NotificationType.FAILED_ACCOUNT,
            "pending": NotificationType.GENERAL,
            "in_progress": NotificationType.GENERAL
        }
        notification_type = type_map.get(status, NotificationType.GENERAL)

        notification_in = NotificationCreate(
            user_id=user_id,
            title=title,
            message=message,
            type=notification_type
        )
        return await self.create_notification(notification_in)

    async def _get_active_admin_emails(self) -> List[str]:
        from sqlmodel import select
        from app.models.admin import Admin

        # Assuming Status=True means active based on the boolean field in Admin model
        query = select(Admin.email).where(Admin.Status == True)
        result = await self.repo.session.exec(query)
        return result.all()

    async def send_email_to_admins(self, subject: str, template_name: str, context: dict, background_tasks: BackgroundTasks) -> None:
        from app.service.mail import send_email

        admin_emails = await self._get_active_admin_emails()
        for email in admin_emails:
            background_tasks.add_task(
                send_email,
                email_to=email,
                subject=subject,
                template_name=template_name,
                context=context
            )
